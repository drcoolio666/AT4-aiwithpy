## Training Introduction Huskylens

Train HuskyLens to recognise printed visual tags using its onboard AI model.

## Resources

- HuskyLens connected as in Activity 1 - see resources on training activity
- `tags_tutorial.png` (printout or on-screen)
- USB cable and Thonny for serial output

## 1 – Prepare the HuskyLens

1. Power on the Maqueen and HuskyLens.
2. Turn the mode dial to **“Tag Recognition.”**
3. Ensure it displays the live camera feed.

## 2 – Train Tags

1. Point the HuskyLens at **Tag 1** on the provided sheet.
2. Long-press the **Learning Button** to capture it → the camera shows **ID 1**.
3. Repeat for **Tag 2** and **Tag 3**, which become IDs 2 and 3.
4. Observe that the HuskyLens draws boxes with recognised IDs when tags reappear.

## 3 – Print Detected Tags

Create a new file `husky_test.py` on your micro:bit:

```python
# Example code
from huskylens import HuskyLens
import utime

hl = HuskyLens()

while True:
    blocks = hl.read_blocks()
    if blocks:
        for b in blocks:
            print("Tag ID:", b.ID, "X:", b.x, "Y:", b.y)
    else:
        print("No tag detected")
    utime.sleep(1)
```

Run the code and move each tag in front of your camera.  
Watch the terminal output for tag IDs and coordinates.

## Step 4 – Record Your Results

| Tag ID | Recognised (Y/N) | Confidence (%) | Lighting/Distance Notes |
| ------ | ---------------- | -------------- | ----------------------- |
| 1      |                  |                |                         |
| 2      |                  |                |                         |
| 3      |                  |                |                         |

**Share your findings with the group**

- How does HuskyLens learn a new tag?
- What happens when two tags appear at once?
- How might environmental factors change recognition confidence?
