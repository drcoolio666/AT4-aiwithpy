# Research and Test ML Vision Models

Research and test simple ML image recognition approaches

## You Will Need

- Kaggle or Colab notebook
- Internet access (for `scikit-learn`)
- Tags provided

## 1 – Research

Investigate three ML model type:

| Student | Model                              | Description Focus                      |
| ------- | ---------------------------------- | -------------------------------------- |
| 1       | k-Nearest Neighbour (KNN)          | Simplicity and distance-based learning |
| 2       | Convolutional Neural Network (CNN) | Feature extraction from images         |
| 3       | Decision Tree or SVM               | Rule-based classification              |

## 2 – Simulate in Python

```python
#Example code
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

# Load and split dataset
digits = load_digits()
X_train, X_test, y_train, y_test = train_test_split(
    digits.data, digits.target, test_size=0.3
)

# Train a simple model
model = KNeighborsClassifier(n_neighbors=3)
model.fit(X_train, y_train)

# Evaluate
preds = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, preds))
```

Replace this dataset with provided **tag images** to test accuracy.

---

## 3 – Compare with HuskyLens (Optional if group members identify & succesfully test the library)

| Aspect            | HuskyLens                     | Python ML                 |
| ----------------- | ----------------------------- | ------------------------- |
| Training method   | On-device with “learn” button | Code-based using dataset  |
| Model flexibility | Fixed functions               | Fully configurable        |
| Required data     | Camera input                  | Stored dataset            |
| Processing power  | Low (real-time)               | Moderate (computer/Colab) |

## Consider

- Which approach would you use for a mobile robot and why?
- How does the ML model differ from HuskyLens “learning”?
- What metrics can we use to measure fairness or bias in recognition?

**Share your findings with the group**

- Notebook with testing
- Short written comparisone
- Which would work best on a small device like a micro:bit?
