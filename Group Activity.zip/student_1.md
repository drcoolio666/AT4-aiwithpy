# Activity 1 – Connect and Test Your HuskyLens with the Maqueen

Set up HuskyLens with a BBC micro:bit and Maqueen base, import the libraries, and verify I²C communication between devices.

## Resources

- 1 × BBC micro:bit V2
- 1 × Maqueen robot base - function diagram: https://wiki.dfrobot.com/micro_Maqueen_for_micro_bit_SKU_ROB0148-EN#Function%20Diagram
- 1 × HuskyLens AI Camera
- Jumper wires (SDA / SCL / VCC / GND)
- USB cable
- **Files:**
  - `maqueen.py` (provided)
  - `huskylens.py` (find a make code)

## Step 1 – Confirm & connect Hardware Wiring

| HuskyLens Pin | Connect To (micro:bit) |
| ------------- | ---------------------- |
| SDA           | P20                    |
| SCL           | P19                    |
| VCC           | 3.3 V                  |
| GND           | GND                    |

- Mount the micro:bit into the Maqueen base.
- Turn on the Maqueen power switch.
- Check that both HuskyLens and Maqueen LEDs power on.

## Step 2 – Verify Communication

Copy both libraries to your micro:bit.  
Then create a file named `main.py`:

```python
# Code example
import microbit
from maqueen import Maqueen
from huskylens import HuskyLens
import utime

robot = Maqueen()
huskylens = HuskyLens()

microbit.display.scroll("Testing")

devices = microbit.i2c.scan()
print("I2C devices:", devices)

# LED flash to confirm setup
for _ in range(3):
    robot.led_left(1)
    utime.sleep(0.3)
    robot.led_left(0)
    robot.led_right(1)
    utime.sleep(0.3)
    robot.led_right(0)

print("Setup complete")
```

**Output**

- The terminal prints something like `[16, 50]`  
  (`16` = Maqueen motor driver, `50` = HuskyLens).
- Maqueen LEDs flash alternately.

**Share you findings with the group**
